global_stats={}
wnd_options={label="demoscene", w=1366,h=768,fullscreen=false}
init_scene = "dungeon"
